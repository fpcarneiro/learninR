library('parallel')

### INPUTS:

# SETTINGS
10000 -> M
1 -> n

# SIMULATION INFO
1000 -> iter 
0 -> bank_divers
10 -> interval
0.2 -> particao 

# DEFINITIONS
floor(M*n) -> N
1000 -> Equity0 
rep(1,M) -> prices0 
0.05 -> threshold 
0.35 -> devalue

# ASSUMPTIONS
Equity0/0.04 -> A_0
-1.0536 -> Alpha 
Net_Top.3D <- function(iter0,mu_b,N1=N,M1=M){     
  u.3D <- array(runif(N1*M1*iter0,0,1),dim=c(iter0,N1,M1))
  return(u.3D <= (mu_b/M1))
}

### REGISTER OUTPUT
matrix(NA,as.integer(((interval-bank_divers)/particao)+1),iter) -> bankrupt.cascade

### initialize count for mu_b
1 -> j

dynamics <- function(iter_number,bc=bankrupt.cascade,alpha=Alpha,topologia=Net_0.3D,iter_mub=j,M1=M,N1=N,equity0=Equity0,invest=A_0,prices_0=prices0,shock=devalue){
  #initial assumptions
  (0.8*invest/rowSums(topologia[iter_number,,]))*topologia[iter_number,,] -> Q_0
  # foi omitido o pre�o inicial pois � igual a 1.
  Q_0[is.nan(Q_0)] <- 0
  Q_0 -> Q_s
  
  ### STEP 1 (TOXIC ASSET)
  prices_0 -> prices_s
  sample(1:M1,1) -> toxic_index

  prices_s[toxic_index] = (1-shock)*prices_0[toxic_index]
  ((0.8*invest - colSums(prices_s*t(Q_s))) <= equity0) -> solvencia_t 
  as.numeric(rep(TRUE,N1)) -> solvencia_s
  
  ### LOOP STEP (2,3,4)
  while(sum(solvencia_t-solvencia_s)!=0){
      
    ### STEP 2
    solvencia_t -> solvencia_s
    solvencia_s*Q_s -> Q_t
      
    ### STEP 3
    colSums(Q_t) -> qtd.liq.num  #!!!!
    colSums(Q_0) -> qtd.liq.denom #-  colSums(Q_s)     #!!!!
    1 - qtd.liq.num/qtd.liq.denom -> liq_frac   #!!!!
    liq_frac[is.nan(liq_frac)] <- 0
    prices_t <- prices_s*exp(alpha*liq_frac)
      
    ### STEP 4
    solvencia_t <- ( (0.8*invest - colSums(prices_t*t(Q_t))) <= equity0 )   #!!!!!!
      
    ### RECORD OLD VALUES FOR LOOPING
    Q_s <- Q_t
    prices_s <- prices_t
      
  }
  return(sum(rowSums(Q_s) == 0) - sum(rowSums(Q_0) == 0))
}

num.cores <- detectCores()

### ALGORITHM OF DYNAMICS ###
while(bank_divers <= interval){

  Net_Top.3D(iter,bank_divers) -> Net_0.3D
  # isso � um cubo (tensor), o restante ser� mantido (matrizes e vetores), 
  # final ser� salvo em tensor
  mclapply(X=seq(from=1,to=iter,by=1),FUN=dynamics) -> aux
  bankrupt.cascade[j,] = unlist(aux)

  j <- j + 1
  bank_divers <- bank_divers + particao
  print(bank_divers)
}




Global.Cascade = (bankrupt.cascade > threshold*N)
PC = rowSums(Global.Cascade)/iter
AEC = rowSums(Global.Cascade*bankrupt.cascade)/(PC*iter*N)
AEC[is.nan(AEC[1:50])] <- 0            #!!!!!!

plot(PC,type='l',main='contagion and extent',ylim=c(-0.02,1.02))
points(AEC,type='l',col='red')

#View(Global.Cascade*bankrupt.cascade)
#View(bankrupt.cascade)
#View(extent)
#View(probs)