library(data.table)
library(readxl)

nomes <- function(x) {
  return(paste(x, c("Chave","Texto"), sep=" "))
}

DT.processPeriodo <- function(dt) {
  dt[, Periodo := gsub("^K4","", Periodo)]
  dt[, Ano := as.integer(substr(Periodo, 1, 4))]
  dt[, Mes := as.integer(substr(Periodo, 6, 7))]
}

DT.splitBWKeyText <- function(dt, campos = c("Periodo"), campos_return, drop_source ) {
  for (c in campos) {
    if (is.null(campos_return) | is.null(campos_return[[c]])) {
      dt[, c(nomes(c)) := lapply(.SD, splitBWKeyText)[[c]], .SDcols = c(c)]
    } else {
      if (length(campos_return[[c]]) == 2)
        dt[, c(campos_return[[c]]) := lapply(.SD, splitBWKeyText)[[c]], .SDcols = c(c)]
      else
        dt[, c(campos_return[[c]]) := lapply(.SD, splitBWKeyText)[[c]][1], .SDcols = c(c)]
    }
    if (is.null(drop_source[[c]]) == FALSE)
      if(drop_source[[c]] == TRUE)
        dt[, (c) := NULL]
  }
}

DT.removeCompoundBW <- function(dt, campos = c("Periodo Chave"), patterns = c("K4")) {
  i <- 1
  for (c in campos) {
    dt[, c(c) := lapply(.SD, removeCompoundBW, patterns[i]), .SDcols = c(c)]
    i <- i + 1
  }
}

splitBWKeyText <- function(x, new_columns = c("Chave", "Texto")) {
  pattern = "^\\["
  return(lapply(tstrsplit(gsub(pattern,"", x), "] ", names = new_columns), trimws))
}

removeCompoundBW <- function(x, compound_pattern = "PB", ifNA = -1) {
  pattern = paste("^", compound_pattern, sep = "")
  result <- trimws(gsub(pattern,"", x))
  return(ifelse(result == "", ifNA, result))
}

isNAorZero <- function(x) is.na(x) | x == 0

DT.getAllNAorZero <- function(dt) {
  return (apply(dt[ , getNumFields(dt), with=FALSE], MARGIN = 2, FUN=isNAorZero))
}

toRemove <- function(dt, campos = c("all_numeric")) {
  if((is.null(campos)) | (campos[1] == "all_numeric"))
    campos = getNumFields(dt)
  to_remove <- dt[,rowSums(.SD, na.rm = TRUE) == 0, .SDcols = campos]
  return (to_remove)
}

DT.removeRowsAllZero <- function(dt, campos = c("all_numeric")) {
  return (dt[!toRemove(dt, campos)])
}

fillNA <- function(x) {
  temp <- x
  temp[is.na(temp)] <- 0
  return (temp)
}

DT.fillNA <- function(dt, campos = c("all_numeric")) {
  if((is.null(campos)) | (campos[1] == "all_numeric"))
    campos = getNumFields(dt)
#  dt[, c(campos) := lapply(.SD, fillNA), .SDcols = campos]
  if (any(is.na(dt[,.SD, .SDcols = campos]))) {
    for (col in campos) set(dt, which(is.na(dt[[col]])), col, 0)
  }
}

getNumFields <- function(dt) {
  tokeepNum <- sapply(head(dt, 1), is.numeric)
  tokeepInt <- sapply(head(dt, 1), is.integer)
  tokeep <- names(dt[1:5 , which(tokeepNum & !tokeepInt), with=FALSE])
  return (tokeep)
}

getCumSum <- function(dt, from = 1, til = 12, campos = c("all_numeric"), inplace = TRUE, camposby = c("Centro de Lucro", "Ano"), new_suffix = "Acumulado", only_grouped_fields = FALSE) {
  return(getGroupedCalculation(dt, calculation = cumsum, from, til, campos, inplace, camposby, new_suffix, only_grouped_fields))
}

getGroupedCalculation <- function(dt, calculation, from = 1, til = 12, campos = c("all_numeric"), inplace = TRUE, camposby = c("Centro de Lucro", "Periodo"), new_suffix = "", only_grouped_fields = FALSE) {
  if((is.null(campos)) | (campos[1] == "all_numeric"))
    campos = getNumFields(dt)
  
  if((is.null(new_suffix)) | (new_suffix == ""))
    new_fields = campos
  else
    new_fields = paste(campos, new_suffix, sep=" - ")
  
  if (inplace) {
    dt[Mes >= from & Mes <= til, c(new_fields) := lapply(.SD, calculation), by = camposby, .SDcols = campos]
    dt[, c(new_fields) := lapply(.SD, fillNA), .SDcols = c(new_fields)]
  } else {
    dt_temp <- dt[Mes >= from & Mes <= til]
    if(only_grouped_fields) {
      dt_temp <- dt_temp[ , lapply(.SD, calculation), by = camposby, .SDcols = campos]
      setnames(dt_temp, c(campos), c(new_fields))
    }
    else {
      dt_temp[, c(new_fields) := lapply(.SD, calculation), by = camposby, .SDcols = campos]
    }
    return(dt_temp)
  }
}

DT.convertFatorEscalonamento <- function(dt, campos = c("all_numeric")) {
  if((is.null(campos)) | (campos[1] == "all_numeric"))
    campos = getNumFields(dt)
  print (campos)
  dt[, c(campos) := lapply(.SD, convertFatorEscalonamento), .SDcols = c(campos)]
}

convertFatorEscalonamento <- function(x, fator = 1000000) {
  return(x/fator)
}

DT.processNames <- function(dt) {
  return(processName(names(dt)))
}

processName <- function(n) {
  pattern = "\\í"
#  return(toupper(gsub(pattern,"i", n)))
  return(gsub(pattern,"i", n))
}

calculaMargem <- function(dt, fator = 1000000, calcAcumulado = TRUE) {
  dt[, `Margem Operacional Unitaria` := fillNA(`Margem Operacional` * fator/`Volume`)]
  if (calcAcumulado) {
    dt[, `Margem Operacional Unitaria - Acumulado` := fillNA(`Margem Operacional - Acumulado` * fator/`Volume - Acumulado`)]
  }
}

getPerspective <- function(dt, from = 1, til = 12, calculation = sum, camposby = c("Centro de Lucro", "Centro de Lucro Nome", "Ano", "Mes", "Periodo"), campos = c("all_numeric"), visao = "DEFAULT", calcMargem = TRUE ) {
  if((is.null(campos)) | (campos[1] == "all_numeric"))
    campos = setdiff(getNumFields(dt), c("Margem Operacional Unitaria", "Margem Operacional Unitaria - Acumulado", "Ano", "Mes", "Latitude", "Longitude"))
  dt_temp <- getGroupedCalculation(dt, from = from, til = til, calculation = calculation, camposby = camposby, inplace = FALSE, only_grouped_fields = TRUE, campos = campos)
  if (calcMargem) {
    calculaMargem(dt_temp)
  }
  dt_temp[,VISAO := visao]
  return(dt_temp)
}

DT.fill <- function(dt, from = 1, til = 12, campos = "key") {
  if((is.null(campos)) | (campos[1] == "key"))
    campos = key(dt)
  anos = unique(dt[Mes == til, c(Ano)])
  table <- dt[0, .SD, .SDcols = c(campos, "Periodo")]
  for(a in anos) {
    max_periodo = max(dt[Mes >= from & Mes <= til & Ano == a, c(Periodo)])
    dt_unique <- unique(dt[Mes >= from & Mes <= til & Ano == a, .SD, .SDcols = campos])
    res <- data.table(dt_unique, Periodo = max_periodo)
    table <- rbindlist(list(table, res))
  }
  setkeyv(table, key(dt))
  return(table)
}

DT.fullfill <- function(dt, from = 1, til = 12, campos = "key") {
  exclude <- setdiff(campos, key(dt))
  result <- DT.fill(dt, from, til, campos = campos)
  DT.processPeriodo(result)
  anos = unique(result[,Ano])
  r <- merge(result, dt[Ano %in% anos], all=TRUE, by = names(result))
  DT.fillNA(r)
  setkeyv(r, key(dt))
  return (r)
}

mascararDados <- function(x) {
  return(x*runif(length(x), 0.0001, 1.0))
}

DT.mascararDados <- function(dt, campos = c("all_numeric")) {
  if((is.null(campos)) | (campos[1] == "all_numeric"))
    campos = getNumFields(dt)
  dt[, c(campos) := lapply(.SD, mascararDados), .SDcols = c(campos)]
}

#, .SD, .SDcols = setdiff(names(dt), exclude)
GERA_MARGEM <- read_excel("D:/R Stuff/Gera Margem/input/GERA_MARGEM.xlsx", sheet = "DRE")
GERA_MARGEM <- data.table(GERA_MARGEM)

names(GERA_MARGEM) <- DT.processNames(GERA_MARGEM)

DT.processPeriodo(GERA_MARGEM)

#GERA_MARGEM[, Ano := as.integer(format(GERA_MARGEM$Periodo,"%Y"))]
#GERA_MARGEM[, Mes := as.integer(format(GERA_MARGEM$Periodo,"%m"))]

GERA_MARGEM[, Ano := as.integer(substr(GERA_MARGEM$Periodo, 1, 4))]
GERA_MARGEM[, Mes := as.integer(substr(GERA_MARGEM$Periodo, 5, 6))]

setkey(GERA_MARGEM, "Centro de Lucro", Periodo)

DT.fillNA(GERA_MARGEM)
DT.convertFatorEscalonamento(GERA_MARGEM)
#GERA_MARGEM <- DT.removeRowsAllZero(GERA_MARGEM, campos = getNumFields(GERA_MARGEM))

getCumSum(GERA_MARGEM, from = 2, til = 4)
dt <- getCumSum(GERA_MARGEM, from = 2, til = 4, inplace = FALSE)

#######################################################################################################################################

#FAT_LIQ <- read_excel("D:/R Stuff/Gera Margem/input/PBB_PBDPAM001_GERA_FATLIQBR.xls", sheet = "FATLIQ")
FAT_LIQ <-read_excel("D:/R Stuff/Gera Margem/input/PB_PBHABP900_FATLIQ_DRE.xlsx")
#FAT_LIQ <- read_excel("D:/R Stuff/Gera Margem/input/GERA_MARGEM_DETALHE.xlsx")

CAMPOS_NUMERICOS_V0_1 = c("Volume", "Receita Bruta", "Abat. e Descontos", "Encargos Financeiros", "Receita Operacional", "CPV (2)", "Despesas Operacionais")
CAMPOS_NUMERICOS_V0_2 = c("Receita Operacional", "CPV (2)", "Margem Bruta", "Despesas Operacionais", "Margem Operacional", "Volume", "Receita Bruta")
CAMPOS_CENTRO_LUCRO_V0 = c("Centro de Lucro", "Tipo", "Regiao", "Regiao DRE", "Regiao Geografica","Latitude", "Longitude", "Fake", "Area")
CAMPOS_PRODUTO_V0 = c("Produto")
CAMPOS_CLIENTE_V0 = c("Cliente", "Cliente Chave", "Cliente Nome", "Tipo Cliente")
CAMPOS_DATA_V0 = c("Periodo")
CAMPOS_OUTROS_V0 = c("Origem")
CAMPOS_NAO_ESCALONAR_V0 = c("Percentual Volume" ,"Margem Operacional Unitaria", "Volume", "Volume Total", "Latitude" ,"Longitude", "Percentual Volume Origem", "Volume Total Origem")

FAT_LIQ <- data.table(FAT_LIQ)[, .SD, .SDcols = c(union(CAMPOS_NUMERICOS_V0_1, CAMPOS_NUMERICOS_V0_2), CAMPOS_CENTRO_LUCRO_V0, CAMPOS_PRODUTO_V0, CAMPOS_CLIENTE_V0, CAMPOS_DATA_V0, CAMPOS_OUTROS_V0)]

names(FAT_LIQ) <- DT.processNames(FAT_LIQ)
DT.fillNA(FAT_LIQ, campos = union(CAMPOS_NUMERICOS_V0_1, CAMPOS_NUMERICOS_V0_2))
DT.convertFatorEscalonamento(FAT_LIQ, campos = setdiff(getNumFields(FAT_LIQ), CAMPOS_NAO_ESCALONAR_V0))

FAKES <- FAT_LIQ[Fake == "[PBX] Sim"]
MANTIDOS <- FAT_LIQ[!toRemove(FAT_LIQ, campos = CAMPOS_NUMERICOS_V0_1)]

FAKES[, TudoZero := TRUE]
MANTIDOS[, TudoZero := FALSE]

CAMPOS_SPLIT = c("Centro de Lucro", "Produto", "Cliente", "Origem", "Tipo", "Regiao", "Cliente Chave", "Regiao DRE", "Regiao Geografica", "Fake", "Area", "Tipo Cliente")
PATTERNS_SPLIT = c("PBACPB", "PB", "PB", "PB", "PB", "PBBR ", "PBACPB", "", "PB", "PB", "PB", "PB")
CAMPOS_RETURN_SPLIT = list("Centro de Lucro" = c("Centro de Lucro","Centro de Lucro Nome"), "Produto" = c("Produto","Produto Nome"), "Cliente" = c("Cliente", "Cliente Texto"), "Origem" = c("Origem"), "Tipo" = c("Tipo","Tipo Nome"), "Regiao" = c("Regiao","Regiao Nome"), "Cliente Chave" = c("Cliente Chave"), "Regiao DRE" = c("Regiao DRE","Regiao DRE Nome"), "Regiao Geografica" = c("Regiao Geografica","Regiao Geografica Nome"), "Fake" = c("Fake Codigo","Fake"), "Area" = c("Area","Area Nome"), "Tipo Cliente" = c("Tipo Cliente","Tipo Cliente Nome"))
DROP_SOURCE_SPLIT = list("Cliente" = FALSE, "Produto" = FALSE, "Centro de Lucro" = FALSE, "Tipo" = FALSE, "Regiao" = FALSE,"Cliente Chave" = FALSE, "Regiao DRE" = FALSE, "Regiao Geografica" = FALSE, "Fake" = FALSE, "Area" = FALSE, "Tipo Cliente" = FALSE, "Origem" = FALSE)

#CAMPOS_SPLIT = c("Centro de Lucro", "Produto", "Cliente")
#PATTERNS_SPLIT = c("PBACPB", "PB", "PB")
#CAMPOS_RETURN_SPLIT = list("Centro de Lucro" = c("Centro de Lucro","Centro de Lucro Nome"), "Produto" = c("Produto","Produto Nome"), "Cliente" = c("Cliente", "Cliente Texto"))
#DROP_SOURCE_SPLIT = list("Centro de Lucro" = FALSE, "Produto" = FALSE, "Cliente" = FALSE)

DT.splitBWKeyText(FAKES, campos = CAMPOS_SPLIT, 
                  campos_return = CAMPOS_RETURN_SPLIT,
                  drop_source = DROP_SOURCE_SPLIT
)

DT.splitBWKeyText(MANTIDOS, campos = CAMPOS_SPLIT, 
                  campos_return = CAMPOS_RETURN_SPLIT,
                  drop_source = DROP_SOURCE_SPLIT
)

FAT_LIQ <- rbindlist(list(MANTIDOS, FAKES))
DT.removeCompoundBW(FAT_LIQ, campos = CAMPOS_SPLIT, patterns = PATTERNS_SPLIT)

FAT_LIQ[Origem == -1, Origem := "RESULTADO N�O OPERACIONAL"] 
FAT_LIQ[Origem == "OUTROS II", Origem := "AJUSTE DE MEDI��O"] 
FAT_LIQ[Origem == "AJUSTE DE MEDI��O", `Despesas Operacionais` := 0]
FAT_LIQ <- FAT_LIQ[Fake != "Sim"] 

DT.processPeriodo(FAT_LIQ)
setkey(FAT_LIQ, Origem, "Centro de Lucro", Periodo, Produto, "Cliente Chave")


campos_nao_acumular = c("Percentual Volume" , "Margem Operacional Unitaria", "CPV Total", "Despesas Operacionais Total", "Volume Total", "Percentual Volume Origem", "CPV Total Origem", "CPV Total Origem (2)", "Volume Total Origem", "Latitude", "Longitude", "Ano", "Mes", "CountTerminal", "Tipo Cliente")
setkey(FAT_LIQ, Origem, "Centro de Lucro", Periodo, Produto, "Cliente Chave")
imp_campos <- setdiff(setdiff(names(FAT_LIQ), c("Periodo", "Ano", "Mes")), setdiff(getNumFields(FAT_LIQ), c("Latitude", "Longitude")))

CAMPOS_BY = c("Origem")
CAMPOS_BY_DATA = c("Ano", "Mes", "Periodo")
CAMPOS_BY_CL = c("Centro de Lucro", "Centro de Lucro Nome", "Tipo", "Tipo Nome", "Regiao", "Regiao DRE", "Regiao Geografica","Latitude", "Longitude", "Fake", "CountTerminal", "Area", "Area Nome")
CAMPOS_BY_PRODUTO = c("Produto", "Produto Nome")
CAMPOS_BY_CLIENTE = c("Cliente Chave", "Cliente Nome", "Tipo Cliente", "Tipo Cliente Nome")

FAT_LIQ[Fake == "Sim", Origem := "MERCADOINT"]
FAT_LIQ[,CountTerminal := 1]
FAT_LIQ[Fake == "Sim", CountTerminal := 0]

FAT_LIQ <- DT.fullfill(FAT_LIQ, from = 1, til = 12, campos = imp_campos)

FAT_LIQ <- getCumSum(FAT_LIQ, from = 1, til = 12, inplace = FALSE, camposby = c("Origem", "Centro de Lucro", "Produto", "Cliente Chave", "Ano"), only_grouped_fields = FALSE, campos = setdiff(getNumFields(FAT_LIQ), campos_nao_acumular))

FAT_LIQ <- FAT_LIQ[, -c("Percentual Volume" , "Margem Operacional Unitaria", "CPV Total", "Despesas Operacionais Total", "Volume Total", "Percentual Volume Origem", "CPV Total Origem", "CPV Total Origem (2)", "Volume Total Origem")]
calculaMargem(FAT_LIQ)
FAT_LIQ[,VISAO := "FATLIQ"]



































































































































meus_campos = c("VISAO", "Cliente Chave", "Cliente Nome", "Centro de Lucro", "Centro de Lucro Nome", "Volume", "Margem Operacional", "Tipo", "Tipo Nome", "Periodo", "Ano", "Mes", "Origem", "Produto", "Fake")

FAT_LIQ <- data.table(FAT_LIQ)[VISAO == "FATLIQ" & Fake != "Sim", .SD, .SDcols = meus_campos]

tipos_filtrados <- unique(FAT_LIQ[, Tipo])
origens_filtradas <- unique(FAT_LIQ[, Origem])
produtos_filtrados <- unique(FAT_LIQ[, Produto])

setkey(FAT_LIQ, Origem, "Centro de Lucro", Periodo, Produto, "Cliente Chave")
imp_campos <- setdiff(setdiff(names(FAT_LIQ), c("Periodo", "Ano", "Mes")), setdiff(getNumFields(FAT_LIQ), c("Latitude", "Longitude")))

CAMPOS_BY = c("Origem")
CAMPOS_BY_DATA = c("Ano")
CAMPOS_BY_CL = c("Centro de Lucro", "Centro de Lucro Nome", "Tipo", "Tipo Nome", "Regiao", "Regiao DRE", "Regiao Geografica","Latitude", "Longitude", "Fake", "CountTerminal")
CAMPOS_BY_PRODUTO = c("Produto", "Produto Nome")
CAMPOS_BY_CLIENTE = c("Cliente Chave", "Cliente Nome")

FAT_LIQ <- data.table(FAT_LIQ)[, .SD, .SDcols = c(CAMPOS_NUMERICOS_V0_1, CAMPOS_NUMERICOS_V0_2, CAMPOS_CENTRO_LUCRO_V0, CAMPOS_PRODUTO_V0, CAMPOS_CLIENTE_V0, CAMPOS_DATA_V0, CAMPOS_OUTROS_V0)]

DT.fillNA(FAT_LIQ, campos = c(CAMPOS_NUMERICOS_V0_1, CAMPOS_NUMERICOS_V0_2))

FAT_LIQ <- getPerspective(FAT_LIQ, from = 1, til = 2, camposby = c(CAMPOS_BY, CAMPOS_BY_CLIENTE, CAMPOS_BY_DATA), visao = "CLIENTE", calcMargem = FALSE)

calculaMargem(FAT_LIQ, calcAcumulado = FALSE)
#fatliq.cliente <- getPerspective(FAT_LIQ, from = 1, til = 2, camposby = c(CAMPOS_BY, CAMPOS_BY_CLIENTE, CAMPOS_BY_DATA), visao = "CLIENTE")

UTE_BA <- FAT_LIQ[`Cliente Chave` == "GENBA00000"]
UTE_BA_2 <- FAT_LIQ_2[`Cliente Chave` == "GENBA00000"]
















FAT_LIQ <-read_excel("D:/R Stuff/Gera Margem/input/PB_PBHABP900_FATLIQ_DRE.xlsx")

CAMPOS_NUMERICOS_V0_1 = c("Volume", "Receita Bruta", "Abat. e Descontos", "Encargos Financeiros", "Receita Operacional")
CAMPOS_NUMERICOS_V0_2 = c("Receita Operacional", "CPV (2)", "Margem Bruta", "Despesas Operacionais", "Margem Operacional", "Volume", "Receita Bruta")
CAMPOS_CENTRO_LUCRO_V0 = c("Centro de Lucro", "Tipo", "Regiao", "Regiao DRE", "Regiao Geografica","Latitude", "Longitude", "Fake", "Area")
CAMPOS_PRODUTO_V0 = c("Produto")
CAMPOS_CLIENTE_V0 = c("Cliente", "Cliente Chave", "Cliente Nome")
CAMPOS_DATA_V0 = c("Periodo")
CAMPOS_OUTROS_V0 = c("Origem")
CAMPOS_NAO_ESCALONAR_V0 = c("Percentual Volume" ,"Margem Operacional Unitaria", "Volume", "Volume Total", "Latitude" ,"Longitude", "Percentual Volume Origem", "Volume Total Origem")

FAT_LIQ <- data.table(FAT_LIQ)[, .SD, .SDcols = c(CAMPOS_NUMERICOS_V0_1, CAMPOS_NUMERICOS_V0_2, CAMPOS_CENTRO_LUCRO_V0, CAMPOS_PRODUTO_V0, CAMPOS_CLIENTE_V0, CAMPOS_DATA_V0, CAMPOS_OUTROS_V0)]

names(FAT_LIQ) <- DT.processNames(FAT_LIQ)
DT.fillNA(FAT_LIQ, campos = c(CAMPOS_NUMERICOS_V0_1, CAMPOS_NUMERICOS_V0_2))
DT.convertFatorEscalonamento(FAT_LIQ, campos = setdiff(getNumFields(FAT_LIQ), CAMPOS_NAO_ESCALONAR_V0))

FAKES <- FAT_LIQ[Fake == "[PBX] Sim"]
MANTIDOS <- FAT_LIQ[!toRemove(FAT_LIQ, campos = CAMPOS_NUMERICOS_V0_1)]

FAKES[, TudoZero := TRUE]
MANTIDOS[, TudoZero := FALSE]

CAMPOS_SPLIT = c("Centro de Lucro", "Produto", "Cliente", "Origem", "Tipo", "Regiao", "Cliente Chave", "Regiao DRE", "Regiao Geografica", "Fake", "Area")
PATTERNS_SPLIT = c("PBACPB", "PB", "PB", "PB", "PB", "PBBR ", "PBACPB", "", "PB", "PB", "PB")
CAMPOS_RETURN_SPLIT = list("Centro de Lucro" = c("Centro de Lucro","Centro de Lucro Nome"), "Produto" = c("Produto","Produto Nome"), "Cliente" = c("Cliente", "Cliente Texto"), "Origem" = c("Origem"), "Tipo" = c("Tipo","Tipo Nome"), "Regiao" = c("Regiao","Regiao Nome"), "Cliente Chave" = c("Cliente Chave"), "Regiao DRE" = c("Regiao DRE","Regiao DRE Nome"), "Regiao Geografica" = c("Regiao Geografica","Regiao Geografica Nome"), "Fake" = c("Fake Codigo","Fake"), "Area" = c("Area","Area Nome"))
DROP_SOURCE_SPLIT = list("Cliente" = FALSE, "Produto" = FALSE, "Centro de Lucro" = FALSE, "Tipo" = FALSE, "Regiao" = FALSE,"Cliente Chave" = FALSE, "Regiao DRE" = FALSE, "Regiao Geografica" = FALSE, "Fake" = FALSE, "Area" = FALSE)

DT.splitBWKeyText(FAKES, campos = CAMPOS_SPLIT, 
                  campos_return = CAMPOS_RETURN_SPLIT,
                  drop_source = DROP_SOURCE_SPLIT
)

DT.splitBWKeyText(MANTIDOS, campos = CAMPOS_SPLIT, 
                  campos_return = CAMPOS_RETURN_SPLIT,
                  drop_source = DROP_SOURCE_SPLIT
)

FAT_LIQ <- rbindlist(list(MANTIDOS, FAKES))

DT.removeCompoundBW(FAT_LIQ, campos = CAMPOS_SPLIT, patterns = PATTERNS_SPLIT)
DT.processPeriodo(FAT_LIQ)
setkey(FAT_LIQ, Origem, "Centro de Lucro", Periodo, Produto, "Cliente Chave")




library(data.table)
iris <- data.table(iris)

vars <- '\"setosa\"'  
#Update so you can change your vars
filter <- paste0('Petal.Length >= 4')

res <- iris[eval(parse(text=filter))]





FAT_LIQ <-read_excel("D:/R Stuff/Gera Margem/input/GERA_MARGEM_DETALHE_V1.xlsx")
FAT_LIQ <- data.table(FAT_LIQ)